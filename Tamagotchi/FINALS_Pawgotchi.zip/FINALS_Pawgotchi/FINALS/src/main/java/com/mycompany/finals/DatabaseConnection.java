package com.mycompany.finals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DatabaseConnection {

    // Update URL, username, and password to match your Oracle setup
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String DB_USER = "system";
    private static final String DB_PASSWORD = "Password";

    public record SavedPetSummary(
            int petId,
            String name,
            String species,
            int hunger,
            int happiness,
            int energy
    ) { }

    private DatabaseConnection() {
        // Utility class
    }

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    public static void close(Connection conn) {
        if (conn != null) {
            try {
                if (!conn.isClosed()) {
                    conn.close();
                }
            } catch (SQLException ex) {
                DatabaseCloseExceptionHandler.handle(ex);
            }
        }
    }

    public static int searchCreature(Connection conn, String name, String species) throws SQLException {
        String sql = "SELECT pet_id FROM pet WHERE LOWER(name) = LOWER(?) AND LOWER(species) = LOWER(?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ps.setString(2, species);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("pet_id");
                }
            }
        }
        return -1;
    }

    public static Creature loadCreature(Connection conn, int petId) throws SQLException {
        String sql = "SELECT p.name, p.species, s.hunger, s.happiness, s.energy "
                   + "FROM pet p "
                   + "JOIN status s ON p.pet_id = s.pet_id "
                   + "WHERE p.pet_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, petId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String name = rs.getString("name");
                    String species = rs.getString("species");
                    int hunger = rs.getInt("hunger");
                    int happiness = rs.getInt("happiness");
                    int energy = rs.getInt("energy");
                    return new Creature(name, species, hunger, happiness, energy);
                }
            }
        }
        throw new SQLException("Creature not found for ID: " + petId);
    }

    public static int createCreature(Connection conn, String name, String species) throws SQLException {
        String insertPetSql = "INSERT INTO pet (name, species) VALUES (?, ?)";
        int petId = -1;

        try (PreparedStatement ps = conn.prepareStatement(insertPetSql, new String[]{"pet_id"})) {
            ps.setString(1, name);
            ps.setString(2, species);
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    petId = keys.getInt(1);
                }
            }
        }

        if (petId == -1) {
            petId = searchCreature(conn, name, species);
        }
        if (petId == -1) {
            throw new SQLException("Failed to retrieve generated pet_id for " + name);
        }

        String insertStatusSql = "INSERT INTO status (pet_id, hunger, happiness, energy) VALUES (?, 15, 15, 15)";
        try (PreparedStatement psStatus = conn.prepareStatement(insertStatusSql)) {
            psStatus.setInt(1, petId);
            psStatus.executeUpdate();
        }

        return petId;
    }

    public static void updateCreature(Connection conn, int petId, int hunger, int happiness, int energy)
            throws SQLException {
        String sql = "UPDATE status "
                   + "SET hunger = ?, happiness = ?, energy = ?, LastUpdated = SYSDATE "
                   + "WHERE pet_id = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, hunger);
            ps.setInt(2, happiness);
            ps.setInt(3, energy);
            ps.setInt(4, petId);
            ps.executeUpdate();
        }
    }

    public static void deleteCreature(Connection conn, int petId) throws SQLException {
        String deleteMessages = "DELETE FROM messages WHERE pet_id = ?";
        String deleteActivities = "DELETE FROM activities WHERE pet_id = ?";
        String deleteStatus = "DELETE FROM status WHERE pet_id = ?";
        String deletePet = "DELETE FROM pet WHERE pet_id = ?";

        try (PreparedStatement psMsg = conn.prepareStatement(deleteMessages);
             PreparedStatement psAct = conn.prepareStatement(deleteActivities);
             PreparedStatement psStat = conn.prepareStatement(deleteStatus);
             PreparedStatement psPet = conn.prepareStatement(deletePet)) {

            psMsg.setInt(1, petId);
            psMsg.executeUpdate();

            psAct.setInt(1, petId);
            psAct.executeUpdate();

            psStat.setInt(1, petId);
            psStat.executeUpdate();

            psPet.setInt(1, petId);
            psPet.executeUpdate();
        }
    }

     public static void createActivity(Connection conn, int petId, String activityType) throws SQLException {

        String sql = "INSERT INTO activities (pet_id, activity_type) VALUES (?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, petId);
            ps.setString(2, activityType);
            ps.executeUpdate();
            System.out.println("[ACTIVITY SAVED] type = " + activityType);

            }

}

    public static void createMessage(Connection conn, int petId, String messageText, String messageType)
            throws SQLException {
        String sql = "INSERT INTO messages (pet_id, message_text, message_type) VALUES (?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, petId);
            ps.setString(2, messageText);
            ps.setString(3, messageType);
            ps.executeUpdate();
        }
    }

    public static List<SavedPetSummary> getAllCreatures() throws SQLException {
        String sql = "SELECT p.pet_id, p.name, p.species, s.hunger, s.happiness, s.energy "
                   + "FROM pet p "
                   + "JOIN status s ON p.pet_id = s.pet_id "
                   + "ORDER BY p.species, p.name";
        List<SavedPetSummary> pets = new ArrayList<>();

        try (Connection conn = connect();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                pets.add(new SavedPetSummary(
                        rs.getInt("pet_id"),
                        rs.getString("name"),
                        rs.getString("species"),
                        rs.getInt("hunger"),
                        rs.getInt("happiness"),
                        rs.getInt("energy")
                ));
            }
        }
        return pets;
    }
}