package com.mycompany.finals;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.SQLException;

/**Game actions, pet expressions, logging, and persistence during gameplay. */
public class GameActions extends JFrame {
    protected Creature creature;

    // UI Components
    protected  JLabel statusLabel;
    protected  JLabel petImageLabel;
    protected JTextArea logTextArea;
    protected JButton playButton, eatButton, sleepButton, quitButton;
    protected Connection conn;
    protected int petId;

    protected void appendLog(String text) {
    logTextArea.append(text);
    logTextArea.setCaretPosition(logTextArea.getDocument().getLength());
}

    // Update Pet Image Based on Expression
    protected void updatePetImage(int lastAction) {

    String expression;
    String expressionMessage = "";

    // Check the pet's current condition
    if (creature.getEnergy() <= 4) {
        expression = "sleepy";
        expressionMessage = creature.getName() + " is feeling sleepy! It needs some rest."; 
    }

    else if (creature.getHunger() <= 4) {
        expression = "hungry";
        expressionMessage = creature.getName() + " is hungry! Please feed it!"; 
    }
    
   else if (creature.getHappiness() <= 4) {
        expression = "sad";
        expressionMessage = creature.getName() + " is feeling sad! Play with it to cheer it up."; 
   } 
    
    else if (lastAction == 3) {
        expression = "sleep"; 
    }
      
    else if (lastAction == 2) {
        expression = "eat"; 
    }
     
    else {
        expression = "happy";
        expressionMessage = creature.getName() + " is feeling happy!";
    }

    // Display message in Activity Log
    appendLog(expressionMessage + "\n");

    // Save message in SQL Database
    try {

        DatabaseConnection.createMessage(
                conn,
                petId,
                expressionMessage,
                expression.toUpperCase()
        );

    } catch (SQLException e) {
        GameExceptionHandler.ignoreDatabaseError(e);
    }

    // Get Selected Animal
    String animal = creature.getSpecies();

    // Find Correct Imagemessage = creature.getName() + " had fun playing!";
    String imagePath = "/images/" + animal + "_" + expression + ".png";

    java.net.URL imageURL = getClass().getResource(imagePath);

    if (imageURL != null) {

        ImageIcon originalIcon = new ImageIcon(imageURL);

        Image scaledImage = originalIcon.getImage().getScaledInstance(
            250, 250, Image.SCALE_SMOOTH
        );

        petImageLabel.setIcon(new ImageIcon(scaledImage));
        petImageLabel.setText("");

    } else {

        petImageLabel.setIcon(null);
        petImageLabel.setText(
            "Image not found: " + imagePath
        );
    }
}

    
protected void handleAction(int choice) {

    if (creature.isDead()) {
        return;
    }

    String message = "";
    String activityType = "";

    switch (choice) {

        case 1 -> {
            creature.play();
            message = creature.getName() + " had fun playing!";
            activityType = "PLAY";
            
            }

        case 2 -> {
            creature.eat();
            message = creature.getName()
                    + " enjoyed a delicious meal!";
            activityType = "EAT";
            }

        case 3 -> {
            creature.sleep();
            message = creature.getName()
                    + " took a nice cozy nap.";
            activityType = "SLEEP";
            }

        case 4 -> {
            JOptionPane.showMessageDialog(
                    this,
                    "Awh. Time to put " + creature.getName()
                            + " to sleep :("
            );
            
           DatabaseConnection.close(conn);
            dispose();
            System.exit(0);
            return; }
    }

    // Save updated creature stats and activity
    try {

        DatabaseConnection.updateCreature(
                conn,
                petId,
                creature.getHunger(),
                creature.getHappiness(),
                creature.getEnergy()
        );

        DatabaseConnection.createActivity(
                conn,
                petId,
                activityType
        );

        DatabaseConnection.createMessage(
                conn,
                petId,
                message,
                activityType
        );

    } catch (SQLException e) {

        GameExceptionHandler.handleSaveError(this, e);
    }

    // Update Game Log and Status
    appendLog(message + "\n");
    statusLabel.setText(creature.Status());

    // Update Pet Expression
    updatePetImage(choice);

    // Check If Creature Died
    if (creature.isDead()) {

        String deathMsg = creature.getDeathReason();

        appendLog("\n[R.I.P.] " + deathMsg + "\n");
        
        JOptionPane.showMessageDialog(
                this,
                deathMsg,
                "Game Over",
                JOptionPane.ERROR_MESSAGE
            );

            playButton.setEnabled(false);
            eatButton.setEnabled(false);
            sleepButton.setEnabled(false);

            quitButton.setText("Your pet is dead");
        
        // Save death message
        try {

    DatabaseConnection.createMessage(
            conn, petId, deathMsg, "DEATH"
    );

    DatabaseConnection.deleteCreature(conn, petId);

    System.out.println(
            "[DELETE] Dead pet and its records have been removed."
    );

} catch (SQLException e) {

    GameExceptionHandler.handleDeleteError(this, e);
            }
        }
    }
}
