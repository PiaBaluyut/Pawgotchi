
package com.mycompany.finals;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class BackgroundPanel extends JPanel {

    private final Image background;

    public BackgroundPanel(String imagePath) {
        background = new ImageIcon(
            getClass().getResource(imagePath)
        ).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        g.drawImage(
            background,
            0, 0,
            getWidth(),
            getHeight(),
            this
        );
    }
}
