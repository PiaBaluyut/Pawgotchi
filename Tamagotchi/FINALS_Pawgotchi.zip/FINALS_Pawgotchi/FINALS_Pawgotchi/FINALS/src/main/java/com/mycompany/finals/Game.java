
package com.mycompany.finals;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.BorderLayout;

public class Game extends GameActions {
    public Game() {
        setTitle("Pawgotchi - Tamagotchi Game");
        setSize(500, 600);
        setResizable(false); 
        setExtendedState(JFrame.NORMAL);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // Choose Species
        String[] speciesOptions = {"Cat", "Dog", "Fox"};

        int speciesChoice = JOptionPane.showOptionDialog(
            this,
            "What kind of animal would you like?",
            "Choose Species",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.QUESTION_MESSAGE,
            null,
            speciesOptions,
            speciesOptions[0]
        );

        if (speciesChoice < 0 || speciesChoice >= speciesOptions.length) {
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    return;
}

String species = speciesOptions[speciesChoice];

final int MAX_NAME_LENGTH = 20;
String name = null;

while (true) {
    String input = JOptionPane.showInputDialog(
        this,
        "What's the name of your " + species.toLowerCase() + "? (Max " + MAX_NAME_LENGTH + " characters)",
        "Name Your Creature",
        JOptionPane.QUESTION_MESSAGE
    );

    if (input == null) {
        break;
    }

    String trimmed = input.trim();

    if (trimmed.isEmpty()) {
        JOptionPane.showMessageDialog(
            this,
            "Please put a name for your " + species.toLowerCase() + ".",
            "Name Required",
            JOptionPane.WARNING_MESSAGE
        );
        continue;
    }

    if (trimmed.length() > MAX_NAME_LENGTH) {
        JOptionPane.showMessageDialog(
            this,
            "Please keep the name to " + MAX_NAME_LENGTH + " characters or fewer.",
            "Name Too Long",
            JOptionPane.WARNING_MESSAGE
        );
        continue;
    }

    boolean hasInvalidChar = false;
    for (int i = 0; i < trimmed.length(); i++) {
        char c = trimmed.charAt(i);
        boolean isLetter = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
        if (!isLetter) {
            hasInvalidChar = true;
            break;
        }
    }

    if (hasInvalidChar) {
        JOptionPane.showMessageDialog(
            this,
            "Special characters aren't allowed. Use only letters A-Z or a-z.",
            "Invalid Characters",
            JOptionPane.WARNING_MESSAGE
        );
        continue;
    }

    name = trimmed;
    break;
}

if (name == null) {
    dispose();
    return;
}

        // Connect to database
   try {

    conn = DatabaseConnection.connect();

    // Search for an existing pet using its name
    petId = DatabaseConnection.searchCreature(conn, name, species);

    if (petId != -1) {

        // Load existing pet
        creature = DatabaseConnection.loadCreature(conn, petId);

        JOptionPane.showMessageDialog(
                this,
                "Welcome back! " + creature.getName()
                + " has been loaded!"
        );

        // Handle a pet that was already dead when loaded
        if (creature.isDead()) {

            DatabaseConnection.deleteCreature(conn, petId);

            JOptionPane.showMessageDialog(
                    this,
                    creature.getName()
                    + " has already passed away. "
                    + "Its records have been deleted."
            );

            // Start a new pet with the same name
            creature = new Creature(name, species);

            petId = DatabaseConnection.createCreature(
                    conn, name, species
            );
        }

    } else {

        // Create a new pet if no matching name exists
        creature = new Creature(name, species);

        petId = DatabaseConnection.createCreature(
                conn, name, species
        );

        JOptionPane.showMessageDialog(
                this,
                "A new pet named " + name + " has been created!"
        );
    }

} catch (SQLException e) {

    GameExceptionHandler.handleStartupError(this, e);
}
        
        // TOP PANEL: Status
        statusLabel = new JLabel(creature.Status(), JLabel.CENTER);
        statusLabel.setFont(new Font("Monospaced", Font.BOLD, 14));
        statusLabel.setBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        );

        add(statusLabel, BorderLayout.NORTH);

        
        // CENTER PANEL: Background, Pet Image, and Game Log
        BackgroundPanel mainPanel =
        new BackgroundPanel("/images/background.jpg");

        // Center the contents even when the window is maximized
        mainPanel.setLayout(new GridBagLayout());

        // Create a content panel to hold the pet and game log
        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setOpaque(false);
        contentPanel.setPreferredSize(new Dimension(500, 450));

        // Pet Image Display
        petImageLabel = new JLabel();
        petImageLabel.setHorizontalAlignment(JLabel.CENTER);
        petImageLabel.setVerticalAlignment(JLabel.CENTER);
        petImageLabel.setPreferredSize(new Dimension(300, 300));

        contentPanel.add(petImageLabel, BorderLayout.CENTER);

        // Game Log (wider at 465px inside the 500px window)
        logTextArea = new JTextArea(
                "Welcome to Pawgotchi! Meet " + creature.getName()
                + " the " + creature.getSpecies() + "!\n"
        );
        logTextArea.setEditable(false);
        logTextArea.setLineWrap(true);
        logTextArea.setWrapStyleWord(true);
        logTextArea.setFont(new Font("Monospaced", Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(logTextArea);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Game Log"));
        scrollPane.setPreferredSize(new Dimension(460, 110));

        contentPanel.add(scrollPane, BorderLayout.SOUTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.insets = new Insets(5, 6, 5, 6);
        mainPanel.add(contentPanel, gbc);

        add(mainPanel, BorderLayout.CENTER);

        // BOTTOM PANEL: Action Buttons
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 8, 8));

        buttonPanel.setBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        );

        playButton = new JButton("Play");
        eatButton = new JButton("Eat");
        sleepButton = new JButton("Sleep");
        quitButton = new JButton("Quit");
        
        playButton.setFont(new Font("Monospaced", Font.BOLD, 12));
        eatButton.setFont(new Font("Monospaced", Font.BOLD, 12));
        sleepButton.setFont(new Font("Monospaced", Font.BOLD, 12));
        quitButton.setFont(new Font("Monospaced", Font.BOLD, 12));
        
        buttonPanel.add(playButton);
        buttonPanel.add(eatButton);
        buttonPanel.add(sleepButton);
        buttonPanel.add(quitButton);

        add(buttonPanel, BorderLayout.SOUTH);

        // BUTTON LISTENERS
        playButton.addActionListener(e -> handleAction(1));
        eatButton.addActionListener(e -> handleAction(2));
        sleepButton.addActionListener(e -> handleAction(3));
        quitButton.addActionListener(e -> handleAction(4));

        // Show Initial Pet Image
        updatePetImage(0);
    }
}
