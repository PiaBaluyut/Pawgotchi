package com.mycompany.finals;

import javax.swing.SwingUtilities;

public class FINALS {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainMenu menu = new MainMenu();
            menu.setVisible(true);
        });
    }
}